Iconset: Social Media (https://www.iconfinder.com/iconsets/social-media-outline-6)
Author: Alex Mitov (https://www.iconfinder.com/alexmitov)
License: Free for commercial use ()
Download date: 2022-03-12